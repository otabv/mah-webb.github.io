<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Resultat</title>
</head>

<body>
<?php
//här ska funktionen rectanglearea defineras

//här ska funktionen trianglearea definieras

$width=$_GET['width'];
$height=$_GET['height'];
echo "en rektangel med bredden $width och höjden $height ";
echo "har arean ";
echo rectanglearea($width,$height);
echo "<br />";
echo "en triangel med bredden $width och höjden $height ";
echo "har arean ";
echo trianglearea($width,$height);
echo "<br />";
?>

</body>
</html>