<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Albums</title>
</head>
<body>
<h1>Albums</h1>
<?php
include $_SERVER['DOCUMENT_ROOT'].'/ändra_till_ert_userid/me105a/connect.php';
$sql="SELECT album.id as albumid,album.title as albumtitle,track.id as trackid,track.title as tracktitle 
FROM album INNER JOIN track ON album_id=album.id 
ORDER BY album.id";

echo "Here is the sql used for the search: ";
echo "<pre>$sql</pre>";

$result=$pdo->query($sql);
$lastalbumid=0; 
foreach ($result as $row) {
	$albumid=$row['albumid'];
	$trackid=$row['trackid'];
	$albumtitle=$row['albumtitle'];
	$tracktitle=$row['tracktitle'];
	if ($albumid!=$lastalbumid) { //dvs om vi är på ett nytt album så skriv ut rubrik med titel 
		echo "<h2>$albumtitle</h2>";
	}
	echo "$tracktitle<br>";
	$lastalbumid=$albumid; //kom ihåg vilket album vi just visat
}
?>




</body>
</html>