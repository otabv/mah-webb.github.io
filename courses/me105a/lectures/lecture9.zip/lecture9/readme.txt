Sidan albums.php gör en join-sökning i tabellerna track och album och visar en lista med alla album och deras tracks. För att köra albums.php måste dels ditt eget användarnamn in i filen, dels måste tabellerna album, track och artist skapas och fyllas med data. Det görs med filerna album.txt, track.txt och artist.txt. Starta MySQL-hanteraren (dvwebb.mah.se, manage mysql etc). Välj sedan Load SQL (grön pil som pekar nedåt) och välj en fil i taget. När en fil laddats in väljer du RunAll. 

Filen albums_nolink.xml är en xml-fil med samma innehåll som albums och tracks. Filen albums.xml är samma fil men med en länk till albums.xsl vilket gör att den visas formatterat ungefär som albums.php. 

Testa filerna. En bugg i chrome gör att albums.xml inte alltid visas korrekt. 